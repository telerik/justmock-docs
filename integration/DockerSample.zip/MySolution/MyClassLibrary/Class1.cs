﻿using System;

namespace MyClassLibrary
{
    public class Class1
    {
        public int Method1(int param)
        {
            return param;
        }
    }
}
