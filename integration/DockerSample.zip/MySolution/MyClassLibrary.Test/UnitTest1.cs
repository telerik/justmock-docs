using Microsoft.VisualStudio.TestTools.UnitTesting;
using Telerik.JustMock;
using MyClassLibrary;

namespace MyClassLibrary.Test
{
    [TestClass]
    public class UnitTest1
    {
        [TestMethod]
        public void TestMethod1()
        {
            // Arrange
            var sut = Mock.Create<Class1>();
            int expected = 5;
            Mock.Arrange(() => sut.Method1(Arg.AnyInt)).Returns(expected);

            // Act 
            int actual = sut.Method1(10);

            // Assert
            Assert.AreEqual(actual, expected);
        }
    }
}
